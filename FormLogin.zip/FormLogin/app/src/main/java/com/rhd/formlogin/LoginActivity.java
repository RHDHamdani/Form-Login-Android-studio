package com.rhd.formlogin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    private Button btnlogin;
    private EditText editUSER,editPASS;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btnlogin = findViewById(R.id.btnlogin);
        editPASS = findViewById(R.id.editpass);
        editUSER = findViewById(R.id.edituser);

        final String username ="Hamdani";
        final String password ="Hamdani";

        btnlogin.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {


                if (editUSER.getText().toString().equals("Hamdani") && editPASS.getText().toString().equals("hamdani")){
                    startActivity(new Intent(LoginActivity.this,MainActivity.class));
                    Toast.makeText(getApplicationContext(),"Acces Accepted",Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(getApplicationContext(),"Acces Denied",Toast.LENGTH_LONG).show();
                }

//                if (editUSER.getText().toString().equals("Hamdani") && editPASS.getText().toString().equals("hamdani")){
//                    startActivity(new Intent(LoginActivity.this,MainActivity.class));
//                    Toast.makeText(getApplicationContext(),"Acces Accepted",Toast.LENGTH_LONG).show();
//                }
//                else{
//                    Toast.makeText(getApplicationContext(),"Acces Denied",Toast.LENGTH_LONG).show();
//                }
           }
        });
    }
}